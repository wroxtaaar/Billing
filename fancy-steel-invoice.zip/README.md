# Fancy Steel Works - Invoice Maker

Single-file website (index.html). No build step.

## Customer list
- The built-in list lives inside index.html in the block `<script id="seed" type="application/json">`.
  One array per Location, each customer has: name, address, gstin, state, stateCode, placeOfSupply.
- customers.json is a copy of the same list.
- To update it: edit that block (or replace it with the new customers.json contents).
  When the list changes, the app merges it into the browser's saved customers on the next load.
  Saved bills are never touched.
- In the app: Customers tab can add/edit customers, import JSON, or show the current list as JSON.

## Notes
- Bills, customers and products are stored in the browser's localStorage on each device.
- Image export uses html2canvas from cdnjs (needs internet).
