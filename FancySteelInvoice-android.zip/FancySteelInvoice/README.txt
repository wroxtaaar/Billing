Fancy Steel Invoice - Android Studio project
1. Install Android Studio (free), choose File > Open, select this folder.
2. Wait for Gradle sync (needs internet the first time).
3. Run on a phone (USB debugging) or emulator, or Build > Build APK(s) to get app-debug.apk.
The whole app is app/src/main/assets/index.html - edit it to change the UI.
